package com.example.kuis_marsha

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
