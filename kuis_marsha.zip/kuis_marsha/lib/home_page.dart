import 'package:flutter/material.dart';
import 'package:flutter_kuis_124220052/bantuan_page.dart';

import 'package:flutter_kuis_124220052/daftar_barang_dummy.dart';

class HomePage extends StatelessWidget {
  final String username;

  HomePage({required this.username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Halaman Home')),
      body: Column(
        children: [
          Text('Selamat datang, $username', style: TextStyle(fontSize: 24)),
          GestureDetector(
            onTap: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => HelpPage()));
            },
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Text('Bantuan', style: TextStyle(fontSize: 18)),
              ),
            ),
          ),
          Expanded(child: SupermarketGridView()),
        ],
      ),
    );
  }
}

class SupermarketGridView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
      ),
      itemCount: supermarketItemList.length,
      itemBuilder: (context, index) {
        SupermarketItem items = supermarketItemList[index];
        return Card(
          child: Column(
            children: [
              Image.network(
                items.imageUrls[0],
              ),
              Text(items.name),
              Text(items.price),
              Text("Stock: -")
            ],
          ),
        );
      },
    );
  }
}
